print 'Hello from eggtest!'
