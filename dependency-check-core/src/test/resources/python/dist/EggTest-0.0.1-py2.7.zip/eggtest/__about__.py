__all__ = ["__title__", "__summary__", "__uri__", "__version__", "__author__",
	"__email__" ]

__title__ = "EggTest"
__summary__ = "Simple project for producing an .egg."
__uri__ = "http://example.org/eggtest"
__version__ = "0.0.1"
__author__ = "Dale Visser"
__email__ = "dvisser@ida.org"