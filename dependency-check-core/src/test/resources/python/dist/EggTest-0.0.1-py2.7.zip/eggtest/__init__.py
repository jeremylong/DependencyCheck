from eggtest import main
